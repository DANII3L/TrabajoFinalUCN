package com.example.finalproject;

public class User {
    public String usuario,password,nombre;
}
